package com.example.tatiapp;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import java.io.Serializable;

@Entity(tableName = "task")
public class Task implements Serializable {

    @PrimaryKey(autoGenerate = true)
    private int id;
    private String name;
    private String date; // Added date field
    private String time;
    private int priority; // 0: Low, 1: High

    // Getters and setters
    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    public String getName() { return name; }

    public void setName(String name) { this.name = name; }

    public String getDate() { return date; } // Added getDate method

    public void setDate(String date) { this.date = date; } // Added setDate method

    public String getTime() { return time; }

    public void setTime(String time) { this.time = time; }

    public int getPriority() { return priority; }

    public void setPriority(int priority) { this.priority = priority; }

}
