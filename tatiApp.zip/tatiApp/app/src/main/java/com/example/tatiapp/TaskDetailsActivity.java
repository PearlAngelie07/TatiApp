package com.example.tatiapp;

import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class TaskDetailsActivity extends AppCompatActivity {

    private EditText taskTimeEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task);

        taskTimeEditText = findViewById(R.id.task_time_edit_text);

        // Set OnClickListener to taskTimeEditText
        taskTimeEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTimePickerDialog();
            }
        });
    }

    // Method to show TimePicker dialog
    private void showTimePickerDialog() {
        final Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        // Format the selected time
                        String selectedTime = String.format("%02d:%02d", hourOfDay, minute);
                        taskTimeEditText.setText(selectedTime);
                    }
                }, hour, minute, true); // 24 hour format

        timePickerDialog.show();
    }

    // TODO: Implement save and delete functionality
    public void onSaveButtonClick(View view) {
        // Save task details
        Toast.makeText(this, "Task saved", Toast.LENGTH_SHORT).show();
    }

    public void onDeleteButtonClick(View view) {
        // Delete task
        Toast.makeText(this, "Task deleted", Toast.LENGTH_SHORT).show();
    }
}
