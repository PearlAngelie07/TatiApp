package com.example.tatiapp;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.NumberPicker;

public class CustomTimePickerDialog extends Dialog {

    private Context context;
    private OnTimeSetListener onTimeSetListener;
    private NumberPicker hourPicker;
    private NumberPicker minutePicker;
    private Button okButton;
    private Button cancelButton;

    public CustomTimePickerDialog(Context context, OnTimeSetListener onTimeSetListener) {
        super(context);
        this.context = context;
        this.onTimeSetListener = onTimeSetListener;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_custom_time_picker);

        hourPicker = findViewById(R.id.hour_picker);
        minutePicker = findViewById(R.id.minute_picker);
        okButton = findViewById(R.id.ok_button);
        cancelButton = findViewById(R.id.cancel_button);

        hourPicker.setMinValue(0);
        hourPicker.setMaxValue(23);

        minutePicker.setMinValue(0);
        minutePicker.setMaxValue(59);

        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onTimeSetListener != null) {
                    onTimeSetListener.onTimeSet(hourPicker.getValue(), minutePicker.getValue());
                }
                dismiss();
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }

    public interface OnTimeSetListener {
        void onTimeSet(int hours, int minutes);
    }
}
