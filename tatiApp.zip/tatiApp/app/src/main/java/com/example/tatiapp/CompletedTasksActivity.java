package com.example.tatiapp;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class CompletedTasksActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private CompletedTaskAdapter completedTaskAdapter;
    private List<Task> completedTaskList = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_completed_tasks);

        // Initialize views
        recyclerView = findViewById(R.id.completed_tasks_recycler_view);

        // Initialize RecyclerView and Adapter
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        completedTaskAdapter = new CompletedTaskAdapter(completedTaskList);
        recyclerView.setAdapter(completedTaskAdapter);

        // Load completed tasks from database
        loadCompletedTasks();
    }

    private void loadCompletedTasks() {
        // Implement logic to load completed tasks from database
        // Add completed tasks to completedTaskList
        completedTaskAdapter.notifyDataSetChanged();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.completed_tasks_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.delete_all) {// Implement logic to delete all completed tasks
            completedTaskList.clear();
            completedTaskAdapter.notifyDataSetChanged();
            return true; // Return true to indicate that the event has been handled
        }
        return super.onOptionsItemSelected(item);
    }

}
