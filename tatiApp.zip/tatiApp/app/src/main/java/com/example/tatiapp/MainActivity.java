package com.example.tatiapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    private ImageView backgroundImage;
    private RelativeLayout welcomeContainer; // Added reference to the welcome container
    private TextView welcomeMessage;
    private RecyclerView recyclerView;
    private TaskAdapter taskAdapter;
    private CompletedTaskAdapter completedTaskAdapter;
    private List<Task> taskList = new ArrayList<>();
    private List<Task> completedTaskList = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        backgroundImage = findViewById(R.id.background_image);
        welcomeContainer = findViewById(R.id.welcome_container); // Initialize the welcome container
        welcomeMessage = findViewById(R.id.welcome_message);
        recyclerView = findViewById(R.id.recycler_view);

        // Load background image
        backgroundImage.setImageResource(R.drawable.images);

        // Initialize RecyclerView and Adapters
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        taskAdapter = new TaskAdapter(taskList, this, false);
        completedTaskAdapter = new CompletedTaskAdapter(completedTaskList);

        recyclerView.setAdapter(taskAdapter);

        // Typing animation for welcome message
        welcomeMessageTypingAnimation();

        // Check for existing tasks and display welcome message if no tasks are available
        if (taskList.isEmpty() && completedTaskList.isEmpty()) {
            welcomeContainer.setVisibility(View.VISIBLE); // Set the container visible
        } else {
            welcomeContainer.setVisibility(View.GONE); // Hide the container
        }

        // Add '+' button to navigate to TaskActivity for adding new tasks
        findViewById(R.id.add_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, TaskActivity.class);
                startActivityForResult(intent, 1);
            }
        });

        // Add settings icon to navigate to SettingsActivity
        findViewById(R.id.settings_icon).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
                startActivity(intent);
            }
        });
    }

    // Handle result from TaskActivity
    @SuppressLint("NotifyDataSetChanged")
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            Task newTask = (Task) Objects.requireNonNull(data).getSerializableExtra("newTask");
            boolean isCompleted = data.getBooleanExtra("isCompleted", false);

            if (isCompleted) {
                completedTaskList.add(newTask);
                recyclerView.setAdapter(completedTaskAdapter);
            } else {
                taskList.add(newTask);
                recyclerView.setAdapter(taskAdapter);
            }

            // Update welcome message visibility
            if (taskList.isEmpty() && completedTaskList.isEmpty()) {
                welcomeContainer.setVisibility(View.VISIBLE);
            } else {
                welcomeContainer.setVisibility(View.GONE);
            }
        }
    }

    // Typing animation for welcome message
    private void welcomeMessageTypingAnimation() {
        final String text = "Start your day by organizing tasks!";
        final Handler handler = new Handler();

        Runnable runnable = new Runnable() {
            int index = 0;

            @Override
            public void run() {
                if (index <= text.length()) {
                    welcomeMessage.setText(text.substring(0, index++));
                    handler.postDelayed(this, 150);
                }
            }
        };

        handler.postDelayed(runnable, 500);
    }
}
