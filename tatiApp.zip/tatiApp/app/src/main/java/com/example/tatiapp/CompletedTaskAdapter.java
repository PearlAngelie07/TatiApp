package com.example.tatiapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class CompletedTaskAdapter extends RecyclerView.Adapter<CompletedTaskAdapter.ViewHolder> {

    private List<Task> completedTaskList;

    public CompletedTaskAdapter(List<Task> completedTaskList) {
        this.completedTaskList = completedTaskList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.completed_task_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Task task = completedTaskList.get(position);
        holder.taskName.setText(task.getName());
        holder.taskDate.setText(task.getDate());
        holder.taskTime.setText(task.getTime());
    }

    @Override
    public int getItemCount() {
        return completedTaskList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView taskName;
        TextView taskDate;
        TextView taskTime;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            taskName = itemView.findViewById(R.id.completed_task_name);
            taskDate = itemView.findViewById(R.id.completed_task_date);
            taskTime = itemView.findViewById(R.id.completed_task_time);
        }
    }
}
