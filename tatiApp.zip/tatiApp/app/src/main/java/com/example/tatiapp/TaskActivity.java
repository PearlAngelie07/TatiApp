package com.example.tatiapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

public class TaskActivity extends AppCompatActivity {

    private EditText taskNameEditText;
    private EditText taskTimeEditText;
    private Button saveButton;
    private Button deleteButton;
    private Button priorityButton;
    private TaskDatabase taskDatabase;
    private Task task;
    private boolean isEdit = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task);

        // Initialize views
        taskNameEditText = findViewById(R.id.task_name_edit_text);
        taskTimeEditText = findViewById(R.id.task_time_edit_text);
        saveButton = findViewById(R.id.save_button);
        deleteButton = findViewById(R.id.delete_button);
        priorityButton = findViewById(R.id.priority_button);

        // Initialize Room database
        taskDatabase = Room.databaseBuilder(getApplicationContext(), TaskDatabase.class, "taskDB")
                .allowMainThreadQueries()
                .build();

        // Check if task is being edited
        if (getIntent().hasExtra("task")) {
            task = (Task) getIntent().getSerializableExtra("task");
            taskNameEditText.setText(task.getName());
            taskTimeEditText.setText(task.getTime());
            saveButton.setText("Update");
            isEdit = true;
        } else {
            task = new Task();
        }

        // Set custom time picker dialog for task time
        taskTimeEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTimePickerDialog();
            }
        });

        // Save task
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                task.setName(taskNameEditText.getText().toString());
                task.setTime(taskTimeEditText.getText().toString());

                if (!isEdit) {
                    taskDatabase.taskDao().insert(task);
                } else {
                    taskDatabase.taskDao().update(task);
                }

                setResult(RESULT_OK, new Intent().putExtra("newTask", task));
                finish();
            }
        });

        // Delete task
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                taskDatabase.taskDao().delete(task);
                setResult(RESULT_OK);
                finish();
            }
        });

        // Set priority
        priorityButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (task.getPriority() == 0) {
                    task.setPriority(1);
                    priorityButton.setText("Priority: High");
                } else {
                    task.setPriority(0);
                    priorityButton.setText("Priority: Low");
                }
            }
        });
    }

    public void showTimePickerDialog() {
        CustomTimePickerDialog dialog = new CustomTimePickerDialog(TaskActivity.this, new CustomTimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(int hours, int minutes) {
                taskTimeEditText.setText(String.format("%02d:%02d", hours, minutes));
            }
        });
        dialog.show();
    }
}
